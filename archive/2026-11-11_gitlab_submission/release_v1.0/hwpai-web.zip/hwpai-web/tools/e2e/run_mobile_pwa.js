// 휴대폰(Pixel 7 에뮬레이션)에서 앱 설치 가능성·오프라인 변환 시험
const { chromium, devices } = require('playwright');
(async () => {
  const [url, dir, out] = process.argv.slice(2);
  const fs = require('fs'), path = require('path');
  const files = fs.readdirSync(dir).filter(f => /\.hwp$/i.test(f)).map(f => path.join(dir, f));
  const b = await chromium.launch({ args: ['--disable-dev-shm-usage'] });
  const ctx = await b.newContext({ ...devices['Pixel 7'], acceptDownloads: true });
  const p = await ctx.newPage();
  const reqs = []; p.on('request', r => reqs.push(r.url()));
  p.on('pageerror', e => console.log('PAGEERR', e.message.slice(0, 200)));
  const run = async (tag) => {
    await p.waitForFunction(() => window.__hwpai && window.__hwpai.ready, null, { timeout: 240000 });
    await p.setInputFiles('#fileInput', files);
    const t0 = Date.now();
    await p.waitForFunction(() => { const S = window.__hwpai; return S.items.length && S.running === 0 && S.items.every(i => !['대기', '큐', '처리중'].includes(i.status)); }, null, { timeout: 600000 });
    const res = await p.evaluate(() => window.__hwpai.items.map(i => [i.rel, i.status, i.verdict || i.audit || '']));
    console.log(tag, 'done', (Date.now() - t0) / 1000, 's', JSON.stringify(res));
    const [dl] = await Promise.all([p.waitForEvent('download', { timeout: 120000 }), p.click('#btnZip')]);
    await dl.saveAs(out + '_' + tag + '.zip'); console.log(tag, 'zip', dl.suggestedFilename(), fs.statSync(out + '_' + tag + '.zip').size);
    await p.screenshot({ path: out + '_' + tag + '.png', fullPage: false });
  };
  await p.goto(url);
  await run('online');
  await p.waitForFunction(() => window.HWPAI_PWA && window.HWPAI_PWA.sw === 'ready', null, { timeout: 60000 });
  const cdp = await ctx.newCDPSession(p);
  const inst = await cdp.send('Page.getInstallabilityErrors');
  const man = await cdp.send('Page.getAppManifest');
  console.log('installability errors', JSON.stringify(inst.installabilityErrors), 'manifest errors', JSON.stringify(man.errors));
  console.log('mobile', JSON.stringify(await p.evaluate(() => window.HWPAI_PWA)), 'pickDir hidden', await p.evaluate(() => document.querySelector('#pickDir').hidden));
  const cached = await p.evaluate(async () => { const ks = await caches.keys(); const c = await caches.open(ks[0]); return [ks, (await c.keys()).length]; });
  console.log('cache', JSON.stringify(cached));
  // 오프라인
  await ctx.setOffline(true);
  const before = reqs.length;
  await p.reload();
  await run('offline');
  const ext = reqs.filter(u => !/^(http:\/\/127\.0\.0\.1:8765|blob:|data:)/.test(u));
  console.log('external requests', ext.length, ext.slice(0, 5).join(' | '));
  await b.close();
})();
