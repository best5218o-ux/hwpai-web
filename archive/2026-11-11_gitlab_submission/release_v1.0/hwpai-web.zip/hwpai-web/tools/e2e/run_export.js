const { chromium } = require('playwright');
(async()=>{
 const url=process.argv[2], dir=process.argv[3], out=process.argv[4];
 const b=await chromium.launch({args:['--disable-dev-shm-usage','--disable-gpu','--renderer-process-limit=1']}); const ctx=await b.newContext({viewport:{width:1280,height:900},deviceScaleFactor:2,acceptDownloads:true}); const p=await ctx.newPage();
 p.on('console',m=>{if(m.type()==='error')console.log('C',m.text().slice(0,200))});
 p.on('pageerror',e=>console.log('PAGEERR',e.message.slice(0,300)));
 await p.addInitScript(()=>{localStorage.setItem('hwpai.opts.v1',JSON.stringify({jobs:2,timeout:120,policy:'review',auto:true}))});
 await p.goto(url);
 await p.waitForFunction(()=>window.__hwpai&&window.__hwpai.ready,null,{timeout:180000});
 const cdp=await ctx.newCDPSession(p);
 const data={items:[],files:[dir],dragOperationsMask:1};
 for(const t of ['dragEnter','dragOver','drop']) await cdp.send('Input.dispatchDragEvent',{type:t,x:400,y:300,data});
 await p.waitForFunction(()=>{const S=window.__hwpai;return S.items.length&&S.running===0&&S.items.every(i=>!['대기','큐','처리중'].includes(i.status))},null,{timeout:1200000});
 // 내보내기
 await p.click('#btnExport'); await p.waitForSelector('#xGo');
 await p.check('#xCh');
 await p.screenshot({path:out+'_export.png'});
 const [dl]=await Promise.all([p.waitForEvent('download',{timeout:300000}),p.click('#xGo')]);
 console.log('export file',dl.suggestedFilename()); await dl.saveAs(out+'_export.zip');
 await b.close();
})();
