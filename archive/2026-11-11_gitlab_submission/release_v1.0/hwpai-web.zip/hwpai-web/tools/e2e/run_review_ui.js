const { chromium } = require('playwright');
(async()=>{
 const url=process.argv[2], dir=process.argv[3], out=process.argv[4];
 const b=await chromium.launch({args:['--disable-dev-shm-usage','--disable-gpu','--renderer-process-limit=1']}); const ctx=await b.newContext({viewport:{width:1280,height:900},deviceScaleFactor:2,acceptDownloads:true}); const p=await ctx.newPage();
 p.on('console',m=>{if(m.type()==='error')console.log('C',m.text().slice(0,200))});
 p.on('pageerror',e=>console.log('PAGEERR',e.message.slice(0,300)));
 await p.addInitScript(()=>{localStorage.setItem('hwpai.opts.v1',JSON.stringify({jobs:2,timeout:120,policy:'review',auto:true}))});
 await p.goto(url);
 await p.waitForFunction(()=>window.__hwpai&&window.__hwpai.ready,null,{timeout:180000});
 const cdp=await ctx.newCDPSession(p);
 const data={items:[],files:[dir],dragOperationsMask:1};
 for(const t of ['dragEnter','dragOver','drop']) await cdp.send('Input.dispatchDragEvent',{type:t,x:400,y:300,data});
 await p.waitForFunction(()=>{const S=window.__hwpai;return S.items.length&&S.running===0&&S.items.every(i=>!['대기','큐','처리중'].includes(i.status))},null,{timeout:1200000});
 await p.screenshot({path:out+'_list.png'});
 await p.click('#summary .stat[data-f="wait"]'); await p.waitForTimeout(300);
 await p.screenshot({path:out+'_wait_filter.png'});
 await p.click('#btnReview'); await p.waitForSelector('#review:not([hidden])');
 await p.waitForTimeout(500);
 await p.screenshot({path:out+'_review1.png'});
 // 첫 문서: 모두 아님, 저장
 await p.click('#rv-bulkNo'); await p.click('#rv-save'); await p.waitForTimeout(200);
 // 둘째 문서: 키보드 ]
 await p.keyboard.press(']'); await p.keyboard.press('s'); await p.keyboard.press('j'); await p.keyboard.press('n');
 await p.selectOption('#rv-policy','mask'); await p.keyboard.press('Control+s'); await p.waitForTimeout(300);
 await p.screenshot({path:out+'_review2.png'});
 const st=await p.evaluate(()=>({recs:Object.keys(window.__hwpai.records).length, ls:localStorage.getItem('hwpai.sens.v1').length}));
 console.log('records',JSON.stringify(st));
 // 값이 저장소에 없는지
 const leak=await p.evaluate(()=>{const s=localStorage.getItem('hwpai.sens.v1');const vals=[];for(const it of window.__hwpai.items){if(it.sens&&it.sens.items)for(const x of it.sens.items)vals.push(x.text)}return vals.filter(v=>v.length>=5&&s.includes(v)).length});
 console.log('값이 localStorage 에 들어간 개수',leak);
 await p.click('#rv-close');
 // 상태 대조: JS vs Python 재처리
 const cmp=await p.evaluate(async()=>{
  const S=window.__hwpai,R=HwpaiReview; const res=[];
  const targets=S.items.filter(i=>i.sens&&i.sens.items&&i.sens.items.length).slice(0,12);
  for(const it of targets){
    const buf=await it.file.arrayBuffer();
    const r=await S.pool.run({type:'process',rel:it.rel,dst:it.dst,data:buf,opts:{timeout:120},cfg:{policy:'review',engine_version:S.cfg.engine_version}},[buf],120000,S.records,S.recVer+1000+res.length);
    const js=R.statusOf(it.sens.items,S.records[it.sens.sha256]||null);
    const rowjs=(js.state)+'|'+Object.entries(js.kinds).map(([k,v])=>k+' '+v).join(', ')+(js.probably_ok?' (추정 비민감 '+js.probably_ok+'건)':'');
    const rowpy=(r.row.민감정보||'없음')+'|'+(r.row.민감정보_항목||'');
    res.push([it.rel,rowjs===rowpy||(js.total===0),rowjs,rowpy]);
  }
  return res;});
 const bad=cmp.filter(x=>!x[1]); console.log('상태 대조',cmp.length,'건 중 불일치',bad.length,JSON.stringify(bad.slice(0,3)));
 await p.waitForTimeout(300);
 await p.click('#summary .stat[data-f="all"]');
 // 상세
 await p.click('#rows tr:first-child button[data-act="detail"]'); await p.waitForTimeout(400);
 await p.screenshot({path:out+'_detail.png'}); await p.click('#detailClose');
 await p.click('#netBadge'); await p.waitForTimeout(500); await p.screenshot({path:out+'_net.png'}); await p.click('#netClose');
 await b.close();
})();
