const { chromium } = require('playwright'); const fs=require('fs');
const L=(...a)=>console.log(...a);
(async()=>{
 const b=await chromium.launch({args:['--disable-dev-shm-usage','--disable-gpu','--renderer-process-limit=1']});
 // 1) file:// 전체 동작
 let ctx=await b.newContext({viewport:{width:1280,height:900},acceptDownloads:true}); let p=await ctx.newPage();
 const reqs=[];p.on('request',r=>reqs.push(r.url().slice(0,90)));
 p.on('pageerror',e=>L('PAGEERR',e.message.slice(0,300)));
 p.on('console',m=>{if(m.type()==='error')L('C',m.text().slice(0,200))});
 await p.addInitScript(()=>{localStorage.setItem('hwpai.opts.v1',JSON.stringify({jobs:1,timeout:120,policy:'review',auto:true}))});
 await p.goto('file:///home/claude/outputs/hwpai/web/index.html');
 await p.waitForFunction(()=>window.__hwpai&&window.__hwpai.ready,null,{timeout:180000});
 L('file:// ready; mode:',await p.evaluate(()=>window.__hwpai.assetMode));
 await p.setInputFiles('#dirInput','/tmp/claude-0/asc2');
 await p.waitForFunction(()=>{const S=window.__hwpai;return S.items.length&&S.running===0&&S.items.every(i=>!['대기','큐','처리중'].includes(i.status))},null,{timeout:300000});
 L('file:// items',await p.evaluate(()=>JSON.stringify(window.__hwpai.items.map(i=>[i.rel,i.status,i.row.판정]))));
 const [dl]=await Promise.all([p.waitForEvent('download'),p.click('#btnZip')]); await dl.saveAs('/tmp/claude-0/par/file_zip.zip'); L('file:// zip',dl.suggestedFilename());
 L('file:// requests non-file:',reqs.filter(u=>!/^(file|blob|data):/.test(u)).join('|')||'none','total',reqs.length);
 L('NET',await p.evaluate(()=>JSON.stringify(HwpaiEngine.NET)));
 await ctx.close();
 // 2) 견고성(http)
 ctx=await b.newContext({viewport:{width:390,height:844},deviceScaleFactor:2,acceptDownloads:true}); p=await ctx.newPage();
 p.on('pageerror',e=>L('PAGEERR',e.message.slice(0,300)));
 await p.addInitScript(()=>{localStorage.setItem('hwpai.opts.v1',JSON.stringify({jobs:1,timeout:120,policy:'review',auto:true}))});
 await p.goto('http://127.0.0.1:8765/index.html');
 await p.waitForFunction(()=>window.__hwpai&&window.__hwpai.ready,null,{timeout:180000});
 // 한글(NFD) 파일명 + 폴더 경로를 가진 File 을 직접 만든다
 const b64=fs.readFileSync('/home/claude/hwpai_src/sample_data/sample_plan.hwp').toString('base64');
 const r=await p.evaluate(async(b64)=>{
   const bin=atob(b64);const u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);
   const nfd='업무추진계획 (최종).hwp'.normalize('NFD');
   const mk=(n)=>new File([u],n);
   const dt=new DataTransfer(); const f=mk(nfd); dt.items.add(f); dt.items.add(mk('메모.txt')); dt.items.add(mk('빈.hwp'.replace('빈','')+'x.HWPX'));
   const i=document.querySelector('#fileInput'); i.files=dt.files; i.dispatchEvent(new Event('change'));
   return window.__hwpai.items.map(x=>[x.rel,x.rel===x.rel.normalize('NFC')]);
 },b64);
 L('NFD→NFC',JSON.stringify(r));
 await p.waitForFunction(()=>{const S=window.__hwpai;return S.running===0&&S.items.every(i=>!['대기','큐','처리중'].includes(i.status))},null,{timeout:120000});
 L(await p.evaluate(()=>JSON.stringify(window.__hwpai.items.map(i=>[i.rel,i.status,i.row.판정_이유]))));
 await p.screenshot({path:'/tmp/claude-0/par/mobile.png',fullPage:true});
 // 시간 한도: 1ms → 일꾼 재시작 → 다음 파일 정상
 const t=await p.evaluate(async(b64)=>{
   const S=window.__hwpai; const bin=atob(b64);const u=new Uint8Array(bin.length);for(let i=0;i<bin.length;i++)u[i]=bin.charCodeAt(i);
   const out=[];
   try{await S.pool.run({type:'process',rel:'t.hwp',dst:'t.hwpx',data:u.buffer.slice(0),opts:{timeout:120},cfg:{policy:'review',engine_version:'x'}},[],1)}catch(e){out.push(['timeout',e.kind,e.message])}
   await new Promise(r=>setTimeout(r,200));
   const r2=await S.pool.run({type:'process',rel:'t2.hwp',dst:'t2.hwpx',data:u.buffer.slice(0),opts:{timeout:120},cfg:{policy:'review',engine_version:'x'}},[],120000);
   out.push(['after-restart',r2.row.상태,r2.row.판정]);
   return out;},b64);
 L('timeout test',JSON.stringify(t));
 // 파손 입력(랜덤 바이트 OLE 머리) 처리 — 일꾼이 죽지 않고 실패로
 const t3=await p.evaluate(async()=>{
   const S=window.__hwpai; const u=new Uint8Array(4096); for(let i=0;i<u.length;i++)u[i]=(i*31)&255; u.set([0xD0,0xCF,0x11,0xE0,0xA1,0xB1,0x1A,0xE1]);
   const r=await S.pool.run({type:'process',rel:'bad.hwp',dst:'bad.hwpx',data:u.buffer,opts:{timeout:120},cfg:{policy:'review',engine_version:'x'}},[u.buffer],120000);
   return [r.row.상태,r.row.판정_이유];});
 L('broken ole',JSON.stringify(t3));
 await ctx.close(); await b.close();
})();
