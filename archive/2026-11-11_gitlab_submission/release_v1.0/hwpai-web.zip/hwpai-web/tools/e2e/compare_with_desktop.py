import os,sys,json,hashlib,csv,re
D,W=sys.argv[1],sys.argv[2]
def files(root):
    o={}
    for dp,_,fs in os.walk(root):
        for f in fs: o[os.path.relpath(dp+'/'+f,root)]=dp+'/'+f
    return o
a,b=files(D),files(W)
print('only desktop:',sorted(set(a)-set(b))); print('only web:',sorted(set(b)-set(a)))
same=diff=0; dl=[]
sha=lambda p:hashlib.sha256(open(p,'rb').read()).hexdigest()
cat={'hwpx':[0,0],'md':[0,0],'json':[0,0]}
for k in sorted(set(a)&set(b)):
    ext=k.rsplit('.',1)[-1]
    if ext not in cat: continue
    if ext=='json' and not k.startswith('_검증서'): continue
    ok=sha(a[k])==sha(b[k]); cat[ext][0 if ok else 1]+=1
    if not ok: dl.append(k)
import zipfile
def members(p):
    z=zipfile.ZipFile(p); return {i.filename:z.read(i.filename) for i in z.infolist()}
ce=0; cd=[]
for k in dl:
    if k.endswith('.hwpx'):
        (ce:=ce+1) if members(a[k])==members(b[k]) else cd.append(k)
print(cat); print('diff files:',dl[:20]); print('hwpx SHA 다름 중 zip 안 파일 내용 일치:',ce,'내용도 다름:',cd)
# ledger compare
def led(p):
    return {r['원본']:r for r in csv.DictReader(open(p,encoding='utf-8-sig'))}
la,lb=led(D+'/이관대장.csv'),led(W+'/이관대장.csv')
skip={'처리시각','변환_소요ms','순번'}
mism=0
for k in la:
    if k not in lb: print('missing in web',k); continue
    for c in la[k]:
        if c in skip: continue
        if la[k][c]!=lb[k].get(c):
            mism+=1; print('MISMATCH',k,c,repr(la[k][c])[:80],repr(lb[k].get(c))[:80])
print('ledger rows',len(la),len(lb),'field mismatches',mism)
