#!/usr/bin/env python3
"""web/ 빌드 도우미 — 정적 파일만 만든다(서버·외부 호출 없음).
 1) py_bundle.js     : py/ 아래 파이썬 소스(hwpai 본체 복사본·웹 연결층·olefile)를 한 파일로
 2) worker_src.js    : js/worker.js 를 문자열로(file:// 에서 Blob 일꾼을 만들기 위함)
 3) payload/*.js    : 엔진 파일(Pyodide·rhwp wasm 등)을 gzip+base64 로 쪼갠 스크립트 — file:// 로 열 때만 쓴다
    (file:// 에서는 브라우저가 fetch 로 로컬 파일을 못 읽는다. <script src> 는 읽을 수 있다)
 4) MANIFEST.sha256  : 배포 파일 해시
"""
import base64, gzip, hashlib, json, os, sys

W = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
ASSETS = {  # 이름 → 상대경로 (js/engine.js 의 목록과 같다)
    "pyodide.js": "vendor/pyodide/pyodide.js",
    "pyodide.asm.js": "vendor/pyodide/pyodide.asm.js",
    "pyodide.asm.wasm": "vendor/pyodide/pyodide.asm.wasm",
    "python_stdlib.zip": "vendor/pyodide/python_stdlib.zip",
    "pyodide-lock.json": "vendor/pyodide/pyodide-lock.json",
    "rhwp.js": "vendor/rhwp-core/rhwp.js",
    "rhwp_bg.wasm": "vendor/rhwp-core/rhwp_bg.wasm",
    "rhwp-package.json": "vendor/rhwp-core/package.json",
}
CHUNK = 6 * 1024 * 1024  # base64 문자 수


def main():
    py = {}
    for dp, dns, fns in os.walk(os.path.join(W, "py")):
        dns[:] = [d for d in dns if d != "__pycache__"]
        for f in fns:
            if f.endswith(".py"):
                full = os.path.join(dp, f)
                py[os.path.relpath(full, os.path.join(W, "py")).replace("\\", "/")] = open(full, encoding="utf-8").read()
    with open(os.path.join(W, "js", "py_bundle.js"), "w", encoding="utf-8") as f:
        f.write("/* 자동 생성(tools/build.py) — py/ 소스 묶음 */\nwindow.HWPAI_PY=" + json.dumps(py, ensure_ascii=False) + ";\n")
    ws = open(os.path.join(W, "js", "worker.js"), encoding="utf-8").read()
    with open(os.path.join(W, "js", "worker_src.js"), "w", encoding="utf-8") as f:
        f.write("/* 자동 생성(tools/build.py) — js/worker.js 문자열 */\nwindow.HWPAI_WORKER_SRC=" + json.dumps(ws, ensure_ascii=False) + ";\n")
    pd = os.path.join(W, "payload")
    os.makedirs(pd, exist_ok=True)
    for f in os.listdir(pd):
        os.remove(os.path.join(pd, f))
    manifest = []
    for name, rel in ASSETS.items():
        raw = open(os.path.join(W, rel), "rb").read()
        gz = gzip.compress(raw, 9, mtime=0)
        b64 = base64.b64encode(gz).decode()
        chunks = [b64[i:i + CHUNK] for i in range(0, len(b64), CHUNK)]
        files = []
        for i, c in enumerate(chunks):
            fn = f"payload/p_{name}_{i:02d}.js"
            with open(os.path.join(W, fn), "w", encoding="ascii") as f:
                f.write(f'__hwpaiChunk({json.dumps(name)},{i},{json.dumps(c)});\n')
            files.append(fn)
        manifest.append({"name": name, "raw": len(raw), "gz": len(gz), "sha256": hashlib.sha256(raw).hexdigest(), "chunks": files})
    with open(os.path.join(W, "payload", "manifest.js"), "w", encoding="utf-8") as f:
        f.write("window.HWPAI_PAYLOAD=" + json.dumps(manifest) + ";\n")
    print("payload", sum(m["gz"] for m in manifest) // 1024, "KB gz")

    # 5) sw.js — 모바일·PC 「앱 설치」(PWA)용 오프라인 캐시. http(s)·localhost 로 열 때만 등록된다(file:// 는 해당 없음).
    pre = ["./", "./index.html", "./css/app.css", "./manifest.webmanifest", "./payload/manifest.js",
           "./icons/icon-192.png", "./icons/icon-512.png", "./icons/maskable-192.png", "./icons/maskable-512.png"]
    pre += ["./js/" + f for f in sorted(os.listdir(os.path.join(W, "js"))) if f.endswith(".js")]
    pre += ["./" + r for r in ASSETS.values()]
    h = hashlib.sha256()
    for r in pre:
        fp = os.path.join(W, "index.html" if r == "./" else r[2:])
        h.update(open(fp, "rb").read())
    ver = h.hexdigest()[:12]
    sw = open(os.path.join(W, "tools", "sw_template.js"), encoding="utf-8").read()
    sw = sw.replace("__VERSION__", ver).replace("__FILES__", json.dumps(pre, ensure_ascii=False))
    open(os.path.join(W, "sw.js"), "w", encoding="utf-8").write(sw)
    print("sw.js", ver, len(pre), "files")
    # 4) MANIFEST.sha256 — 배포 폴더의 모든 파일(MANIFEST 자신·__pycache__ 제외). 이전 판은 이 단계를 손으로 해서 새 파일이 빠진 적이 있다.
    lines = []
    for dp, dns, fns in os.walk(W):
        dns[:] = sorted(d for d in dns if d != "__pycache__")
        for fn in sorted(fns):
            rel = "./" + os.path.relpath(os.path.join(dp, fn), W).replace(os.sep, "/")
            if rel == "./MANIFEST.sha256" or fn.endswith(".pyc"):
                continue
            lines.append(f"{hashlib.sha256(open(os.path.join(dp, fn), 'rb').read()).hexdigest()}  {rel}")
    open(os.path.join(W, "MANIFEST.sha256"), "w", encoding="utf-8").write("\n".join(sorted(lines, key=lambda x: x.split("  ", 1)[1])) + "\n")
    print("MANIFEST", len(lines))


if __name__ == "__main__":
    main()
